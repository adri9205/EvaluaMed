<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- Arvhivo encargado de iniciar sesion -->
<html>
<head>
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link rel="stylesheet" href="table.css" type="text/css"/>
<script language="Javascript" type="text/javascript" src="validar.js">
</script>
<script>
function valida(){
	
var i = document.getElementById("correo").value;
var j = document.getElementById("ccorreo").value;
var nombre = document.getElementById("nombre").value;
var apaterno = document.getElementById("apaterno").value;
var amaterno = document.getElementById("amaterno").value;
var especialidad = document.getElementById("especialidad").value;


	if((nombre!="")&&(apaterno!="")&&(amaterno!="")&&(especialidad!="")&&(i!="")&&(j!="")){
	
		if((/^[_a-z0-9-]+(.[_a-z0-9-]+)*@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,4})$/.test(i))&&(/^[_a-z0-9-]+(.[_a-z0-9-]+)*@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,4})$/.test(j))){
		 	if(i==j){
				document.getElementById('Login').submit();
				}
			else{
				alert("Correos no coinciden");
				}
		}
	
		else{
			alert("Formato de correos no valido");
			}
		
	}
	else{
		
		alert("No puede haber campos vacios");
	}
}
function checkSubmit(e)
{
   if(e && e.keyCode == 13)
   {
      valida();
   }
}
	
</script>
<title>Registro de Evaluadores</title>
<meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
</head>

<body>

<h1>EvaluaMed</h1>
<div name="tablaInicio" class="login-block" onKeyPress="return checkSubmit(event)">

 <form action="envio_registro.php" method="post" id="Login">
    
      <h2>Formato para registro de evaluadores</h2>
    
      <input type="email" id="correo" name="correo" placeholder="Correo Electonico" />

    
    
      <input type="email" id="ccorreo" name="ccorreo" placeholder="Confirmar Correo Electonico"  />

    
    
   
      <input type="text" id="nombre" name="nombre" placeholder="Nombre" />

    
    
    
    
      <input type="text" id="apaterno" name="apaterno" placeholder="Apellido Paterno" />

    
    
    
  
      <input type="text" id="amaterno" name="amaterno" placeholder="Apellido Materno" />

    
    
    
      <input type="text" id="especialidad" name="especialidad" placeholder="Especialidad"  />

    
    
    
    
    <input type="button" value="Enviar" onClick="valida()" />
    <input type="button" onClick=" window.location.href='default.html'"   value="Regresar">
   
  </form>
   

 
</table>
</div>
</body>
</html>