<!DOCTYPE html>
<?php
session_start();
$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))||($_SESSION['username']!="admin")){
	
	header("location:default.html");
	
}

include("MenuSuperAdmin.html");
include 'configuration.php';
	?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lista Alumnos</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="table.css" type="text/css"/>
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link href="textos.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<script src="jquery-1.10.2.js"></script>
<script>


function tabla(especialidad) {

	document.getElementById("error").innerHTML = "";
	
		document.getElementById("salida").innerHTML = "";
	        if (window.XMLHttpRequest)
	        {// code for IE7+, Firefox, Chrome, Opera, Safari
	            xmlhttp = new XMLHttpRequest();
	        }
	        else
	        {// code for IE6, IE5
	            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	        }
	        xmlhttp.onreadystatechange = function()
	        {
	            if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
	            {
	                document.getElementById("salida").innerHTML = xmlhttp.responseText;
	            }
	        }
	
	        //Manda comoo argumentos la clave, el numero de pregunta y el orden
	        xmlhttp.open("GET", "tabla_evaluador.php?especialidad=" + especialidad, true);
	        xmlhttp.send();
	        
	        
	        
	       
	
}

function dbgrupo(titular) {

	var especialidad = document.getElementById("especialidad").value;
	var nivel = titular.charAt(0);
	titular = titular.substr(1);
	
		 $.ajax({
	           type: 'GET',
	            url : 'db_tutor.php',
	            async: false,
	            data: {especialidad: especialidad, nivel:nivel, titular:titular},
	            success: function(resultado) {
	                
	            }
	        });
	        
	        

}


function checkSubmit(e)
{
   if(e && e.keyCode == 13)
   {
      dbespecialidad();
   }

}
</script>
</head>
<body style="background-color:lightgrey">
<h3>Seleccione la especialidad</h3>
<div>
<div class="formulario" onKeyPress="return checkSubmit(event)">
       <p>Especialidad:</p>
	<select name="especialidad" id="especialidad" class="gridder_add select" onchange='tabla(this.value)'>
	<option value="0">Seleccionar</option>
	<?php 
                        $result=mysql_query("select * from especialidad ") or die(mysql_error());?>
                   <?php while($row = mysql_fetch_array($result))  { ?>
                        <option value="<?php echo $row['id_especialidad']; ?>"><?php echo $row["nombre"]; ?></option>
                        <?php } 
                        $result=mysql_query("select * from especialidad ") or die(mysql_error());?>
        </select>
        <br>
        <p id="error" class="error"></p>
	<br>
</div>
<div class="salida" id="salida">
</div>
</div>
</body>
</html>