﻿<!DOCTYPE html>
<html>
    <head>
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link rel="stylesheet" href="table.css" type="text/css"/>

        
    </head>
    <body>
    <h1>EvaluaMed</h1>
            <br>
  <div class="login-block">

 
    
      <h3>Contraseña o usuario incorrecto</h3>
    
    <input type="button" onClick=" window.location.href='default.html'"   value="Regresar">

</div>
    </body>
</html>