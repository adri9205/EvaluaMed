<?php

$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))&&($_SESSION['username']=="admin")){
	
	header("location:default.html");
	
}

include 'configuration.php';
		
		
		
			$result=mysql_query("SELECT * FROM `especialidad`") or die(mysql_error());
		
		
		

	$row = mysql_fetch_array($result);
	if($row != NULL){
		
	echo " <p></p>";
	echo "	<table class='as_gridder_table'>";
        echo "    <tr class='grid_header'>";
        echo "        <td>Especialidad</td>";
        echo "        <td>Acciones</td>";
               
        echo "    </tr>";
        
        do{
        
        
        echo "    <tr style='background-color:#FFFFFF'>";
                  
        echo "            <td>".$row['nombre']."</td>";
        echo "            <td onclick=borrar(".$row['id_especialidad'].",'".$row['nombre']."');><a ><img src='images/delete.png' alt='Borrar' title='Borrar' /></a></td>";
                    
                   
                    
	echo "			</tr>";
				
		}while($row = mysql_fetch_array($result)); 
         echo "       </table>";
						
	}  
	
	else {
		
		echo "<p> No se encontr&oacute; alguna especialidad en la base de datos. </p>";

	}
?>