<?php
session_start();
$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))||($_SESSION['username']!="admin")){
	
	header("location:default.html");
	
}

include 'configuration.php';

		$email	 		= $_GET['email'];
		$email_c 		= $_GET['email_c'];

		mysql_query("UPDATE `administrador` SET `correo`='".$email."' WHERE `id_administrador`='".$id."'") or die();
		
		$result=mysql_query("SELECT * FROM `administrador`") or die(mysql_error()); 
		
		$row = mysql_fetch_array($result);
		
				$to = $row['correo'];
				$subject = "Alta Administrador";
				
				$message = "
				<html>
				<head>
				<title>Alta administrador</title>
				</head>
				<body>
				<p>Equipo EvaluaMed:</p>
				<p>Se ha dado de alta este correo como administrador del sistema. A continuaci&oacute;n se despliega la informaci&oacute;n.</p>
				<table>
				<tr>
				<td>Correo:</td><td>".$row['correo']."</td>
				</tr>
				<tr>
				<td>Contrase&ntilde;a:</td><td>".$row['password']."</td>
				</tr>
				</table>
				<p>Este mensaje es autom&aacute;tico favor de no contestar.</p>
				</body>
				</html>
				";
				
				// Always set content-type when sending HTML email
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				
				// More headers
				$headers .= 'From: <mensajes@evaluacionqx.com>' . "\r\n";

				
				mail($to,$subject,$message,$headers);
		
		$respuesta = 1;
		
		// Se manda el nombre del equipo
		echo $respuesta;


	?>