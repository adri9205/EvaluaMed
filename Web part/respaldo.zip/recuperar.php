<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- Arvhivo encargado de iniciar sesion -->
<html>
<head>
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link rel="stylesheet" href="table.css" type="text/css"/>
<script language="Javascript" type="text/javascript" src="validar.js">
</script>
<script>
function valida(){
	
var i = document.getElementById("correo").value;

	if(i!=""){
	 	
			document.getElementById('Login').submit();
		
	}

	else{
		alert("No puede haber campos vacios");
		}
}
	
</script>
<title>Recuperar password</title>
<meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
</head>

<body>

<h1>EvaluaMed</h1>
<div name="tablaInicio" class="login-block" >

 <form action="envio_password.php" method="post" id="Login">
    
      <h2>Ingrese su usuario</h2>
    
      <input type="text" id="correo" name="correo" placeholder="Correo Electonico o Matricula" />
    
    
    
    
    <input type="button" value="Enviar" onClick="valida()" />
    <input type="button" onClick=" window.location.href='default.html'"   value="Regresar">
   
  </form>
   

 
</table>
</div>
</body>
</html>