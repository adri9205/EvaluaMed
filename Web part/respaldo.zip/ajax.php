<?php
include 'configuration.php';
include 'functions/functions.php';
$action = $_REQUEST['action'];

        function getRandomCode(){
	    $an = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-)(.:,;";
	    $su = strlen($an) - 1;
	    return substr($an, rand(0, $su), 1) .
	            substr($an, rand(0, $su), 1) .
	            substr($an, rand(0, $su), 1) .
	            substr($an, rand(0, $su), 1) .
	            substr($an, rand(0, $su), 1) .
	            substr($an, rand(0, $su), 1);
	}

switch($action) {

	case "load":
		$query 	= mysql_query("SELECT * FROM `alumnos` ORDER BY id_alumno ASC");
		$result=mysql_query("select * from especialidad ") or die(mysql_error());
		$count  = mysql_num_rows($query);
		if($count > 0) {
			while($fetch = mysql_fetch_array($query)) {
				$record[] = $fetch;
			}
		}
		$level = array('1', '2', '3', '4','5');
		?>
        <table class="as_gridder_table">
            <tr class="grid_header">
                <td><div class="grid_heading">Sno</div></td>
                <td><div class="grid_heading">Matricula</div></td>
                <td><div class="grid_heading">Nombre(s)</div></td>
                <td><div class="grid_heading">Apellido P</div></td>
                <td><div class="grid_heading">Apellido M</div></td>
                <td><div class="grid_heading">Nivel</div></td>
                <td><div class="grid_heading">Especialidad</div></td>
               
                <td><div class="grid_heading">Actions</div></td>
            </tr>
            <tr id="addnew">
            	<td>&nbsp;</td>
            	<td colspan="6">
                <form id="gridder_addform" method="post">
                <input type="hidden" name="action" value="addnew" />
                <table width="100%">
                <tr>
                    <td><input type="text" name="matricula" id="matricula" class="gridder_add" /></td>
                    <td><input type="text" name="nombre" id="nombre" class="gridder_add" /></td>
                    <td><input type="text" name="apellido_p" id="apellido_p" class="gridder_add" /></td>
                    <td><input type="text" name="apellido_m" id="apellido_m" class="gridder_add" /></td>
                    <td><select name="nivel" id="nivel" class="gridder_add select">
                   <?php foreach($level as $levels) { ?>
                        <option value="<?php echo $levels; ?>"><?php echo $levels; ?></option>
                        <?php } ?>
                        </select></td>
                    <td><select name="especialidad" id="especialidad" class="gridder_add select">
                   <?php while($row = mysql_fetch_array($result))  { ?>
                        <option value="<?php echo $row['nombre']; ?>"><?php echo $row["nombre"]; ?></option>
                        <?php } 
                        $result=mysql_query("select * from especialidad ") or die(mysql_error());?>
                        </select></td>
                    
                   
                    <td>&nbsp;
                    <input type="submit" id="gridder_addrecord" value="" class="gridder_addrecord_button" title="Add" />
                    <a href="cancel" id="gridder_cancel" class="gridder_cancel"><img src="images/delete.png" alt="Cancel" title="Cancel" /></a></td>
				</tr>
                </table>                    
                </form>
            </tr>
            <?php
            if($count <= 0) {
            ?>
            <tr id="norecords">
                <td colspan="7" align="center">No records found <a href="addnew" id="gridder_insert" class="gridder_insert"><img src="imapellido_ps/insert.png" alt="Add New" title="Add New" /></a></td>
            </tr>
            <?php } else {
            $i = 0;
            foreach($record as $records) {
            $i = $i + 1;
            ?>
            <tr class="<?php if($i%2 == 0) { echo 'even'; } else { echo 'odd'; } ?>">
                <td><div class="grid_content sno"><span><?php echo $i; ?></span></div></td>
                <td><div class="grid_content editable"><span><?php echo $records['id_alumno']; ?></span><input type="text" class="gridder_input" name="<?php echo encrypt("matricula|".$records['id_alumno']); ?>" value="<?php echo $records['id_alumnos']; ?>" /></div></td>
                <td><div class="grid_content editable"><span><?php echo $records['nombre']; ?></span><input type="text" class="gridder_input" name="<?php echo encrypt("nombre|".$records['id_alumno']); ?>" value="<?php echo $records['nombre']; ?>" /></div></td>
                <td><div class="grid_content editable"><span><?php echo $records['apellido_p']; ?></span><input type="text" class="gridder_input" name="<?php echo encrypt("apellido_p|".$records['id_alumno']); ?>" value="<?php echo $records['apellido_p']; ?>" /></div></td>
                <td><div class="grid_content editable"><span><?php echo $records['apellido_m']; ?></span><input type="text" class="gridder_input" name="<?php echo encrypt("apellido_m|".$records['id_alumno']); ?>" value="<?php echo $records['apellido_m']; ?>" /></div></td>
                <td><div class="grid_content editable"><span><?php echo $records['nivel']; ?></span>
                <select class="gridder_input select" name="<?php echo encrypt("nivel|".$records['id_alumno']); ?>">
                    <?php foreach($level as $levels) { ?>
                    <option value="<?php echo $levels; ?>" <?php if($levels == $records['nivel']) { echo 'selected="selected"'; } ?>><?php echo $levels; ?></option>
                    <?php } ?>
                </select>
                </div></td>
                <td><div class="grid_content editable"><span><?php echo $records['especialidad']; ?></span>
                <select class="gridder_input select" name="<?php echo encrypt("especialidad|".$records['id_alumno']); ?>">
                    <?php  while($row = mysql_fetch_array($result)) { ?>
                    <option value="<?php echo $row['nombre']; ?>" <?php if($row['nombre'] == $records['especialidad']) { echo 'selected="selected"'; } ?>><?php echo $row['nombre']; ?></option>
                    <?php }
                    $result=mysql_query("select * from especialidad ") or die(mysql_error());  ?>
                </select>
                </div></td>
                
                
                <td>
                <a href="gridder_addnew" id="gridder_addnew" class="gridder_addnew"><img src="images/insert.png" alt="Add New" title="Add New" /></a>
                <a href="<?php echo encrypt($records['id_alumno']); ?>" class="gridder_delete"><img src="images/delete.png" alt="Delete" title="Delete" /></a></td>
            </tr>
            <?php
                }
            }
            ?>
            </table>
        <?php
        

	break;
	
	case "addnew":
		$matricula 		= isset($_POST['matricula']) ? mysql_real_escape_string($_POST['matricula']) : '';
		$nombre 		= isset($_POST['nombre']) ? mysql_real_escape_string($_POST['nombre']) : '';
		$apellido_p 		= isset($_POST['apellido_p']) ? mysql_real_escape_string($_POST['apellido_p']) : '';
		$apellido_m 		= isset($_POST['apellido_m']) ? mysql_real_escape_string($_POST['apellido_m']) : '';
		$nivel 			= isset($_POST['nivel']) ? mysql_real_escape_string($_POST['nivel']) : '';
		$especialidad 		= isset($_POST['especialidad']) ? mysql_real_escape_string($_POST['especialidad']) : '';
		$codigo			= getRandomCode();
		$codigo2		= getRandomCode();
		
		mysql_query("INSERT INTO `alumnos`(`id_alumno`, `nombre`, `apellido_p`, `apellido_m`, `password`, `nivel`, `especialidad`, `codigo`) VALUES ('$matricula','$nombre','$apellido_p','$apellido_m','$codigo','$nivel','$especialidad','$codigo2')") or die();
	break;
	
	
	case "update":
		$value 	= $_POST['value'];
		$crypto = decrypt($_POST['crypto']);
		$explode = explode('|', $crypto);
		$columnName = $explode[0];
		$rowId = $explode[1];
		if($columnName == 'posted_date') { // Check the column is 'date', if yes convert it to date format
			$datevalue = $value;
			$value 	   = date('Y-m-d', strtotime($datevalue));
		}
		$query = mysql_query("UPDATE `alumnos` SET `$columnName` = '$value' WHERE id_alumno = '$rowId' ");
	break;
	
	case "delete":
		$value 	= decrypt($_POST['value']);
		$query = mysql_query("DELETE FROM `alumnos` WHERE id_alumno = '$value' ");
	break;
}
?>