<?php

$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))&&($_SESSION['username']=="admin")){
	
	header("location:default.html");
	
}

include 'configuration.php';

		$nombre 		= $_GET['nombre'];

		mysql_query("INSERT INTO `especialidad`(`nombre`) VALUES ('".$nombre."')") or die();
		
		$result=mysql_query("SELECT * FROM `especialidad` a WHERE  a.nombre = '".$nombre."'") or die(mysql_error()); 
		
		$row = mysql_fetch_array($result);
		
		mysql_query("INSERT INTO `grupos`(`nivel`, `id_titular`, `id_especialidad`) VALUES ('1','','".$row['id_especialidad']."')") or die();
		
		mysql_query("INSERT INTO `grupos`( `nivel`, `id_titular`, `id_especialidad`) VALUES ('2','',".$row['id_especialidad'].")") or die();
		
		mysql_query("INSERT INTO `grupos`( `nivel`, `id_titular`, `id_especialidad`) VALUES ('3','',".$row['id_especialidad'].")") or die();
		
		mysql_query("INSERT INTO `grupos`( `nivel`, `id_titular`, `id_especialidad`) VALUES ('4','',".$row['id_especialidad'].")") or die();
		
		mysql_query("INSERT INTO `grupos`( `nivel`, `id_titular`, `id_especialidad`) VALUES ('5','',".$row['id_especialidad'].")") or die();

	?>