<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<?php
session_start();
$id=$_SESSION['username'];
if(!isset($_SESSION['username'])){
	
	header("location:default.html");
	
}
	?>
<!-- Arvhivo encargado de iniciar sesion -->
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link rel="stylesheet" href="table.css" type="text/css"/>
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="script.js"></script>
<script language="Javascript" type="text/javascript" src="validar.js">
</script>
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<script>
function valida(){
	
var i = document.getElementById('password').value;
var j = document.getElementById('cpassword').value;



	 	if((i!="")&&(j!="")){
	 	
	 			if(i==j){
					document.getElementById('Login').submit();
				}
				else{
					alert("Contraseñas no coinciden");
				}
			}
		else{
			alert("No puede haber campos vacios");
			}

}
	
</script>
</head>

<?php  

$conexion=mysql_connect("localhost","evaluac4_equipo","equipo2222*");
mysql_select_db("evaluac4_base",$conexion);


function getRandomCode(){
    $an = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-)(.:,;";
    $su = strlen($an) - 1;
    return substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1);
}

	$correo=$_GET["correo"];
	$codigo=$_GET["nombre"];
	$codigo_nuevo=getRandomCode();
	$liga='window.location.href="default.html"';
	
	
			$result=mysql_query("select id_evaluadores, codigo from evaluadores a WHERE a.id_evaluadores = '".$correo."' ", $conexion) or die(mysql_error()); 
			
			if($row = mysql_fetch_array($result) != NULL){
			
				if($row["codigo"]!=$codigo){
				
					echo "</head>";
					echo "<body>";
					echo "    <h1>EvaluaMed</h1>";
					echo "            <br>";
					echo "  <div class='login-block'>";
					
					echo "      <h3>Liga vencida</h3>";
					    
					echo "    <input type='button' onClick='".$liga."'   value='Cancelar'>";
					    
					echo "</div>";
					echo "    </body>";
					echo "</html>";
					
					}
					else{
			
					echo "<body>";
					
					echo "<h1>EvaluaMed</h1>";
					echo "<div name='tablaInicio' class='login-block'>";
					
					
					
					echo "<form action='db_evaluador.php' method='post' id='Login'>";
						   
					echo "	    <h2>Formato para registro de evaluadores</h2>";
						   
						  
					 echo "    <input class='req' type='text' id='password' name='password' value='".$correo."' />";
						    

						   
					echo "    <input class='req' type='text' id='cpassword' name='cpassword' value='".$nombre."' />";
						
					    
					    
					
					echo "		<input type='button' value='Cambiar contraseña' onClick='valida()' />";
						  	 
					echo "	  </form>";
						  
					   
					
					 
					
					echo "</div>";
					echo "</body>";
				
				}

			}  
			
							
			
			
			?>