﻿<!DOCTYPE html>
<html>
    <head>
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link rel="stylesheet" href="table.css" type="text/css"/>

        
    </head>
    <body>
    <h2>Juego Marat&oacute;n</h2>
            <br>
  <div class="CSS_Table_Example_Center" style="width:600px;height:150px;" align="center">
<table class="CSS_Table_Example" align="center" width="69%" border="">
 
    <tr>
      <td colspan="4" scope="col">Contraseña o usuario incorrecto !! </td>
    </tr>
    <tr>
    <td></td>
    <td><a class="buttonsDesign" href="index.php">Regresar</a></td>
    </tr>
</table>
</div>
    </body>
</html>
