<!--
juego_individual.php es la base del juego individual
Año de elaboración: 2013
Equipo desarrollador:
Ricardo Molina
Javier Yépiz
Daniel Garza
Erasmo Leal
-->
<!DOCTYPE html>
<?php
session_start();
$usuario = $_SESSION['username'];
$matricula = $_POST['matricula'];
if (!isset($_SESSION['username'])) {

    header("location:../index.php");
}
if ($usuario != $matricula) {

    header("location:../index.php");
}
?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Juego Maraton Individual</title>
        <link rel="stylesheet" type="text/css" href="css.css">
        <script src="jquery-1.10.2.js"></script>
        <script src="script_individual.js"></script>

    </head>
    <?php
    $matricula = $_POST['matricula'];
    $clave = $_POST['clave'];
    $grupo = $_POST['grupo'];
    $parcial = $_POST['parcial'];
    echo "<body onload='inicio(\"" . $matricula . "\",\"" . $clave . "\"," . $grupo . "," . $parcial . ")' class='ty'>";
    ?>
    <div id="pregunta"></div>
    <div class="imagen">
        <img src="img/ciudad.png" alt="fondo" width="100%" height="470" />
        <img src="img/cocostands.gif" id="cocodrilo" class="cocodrilo" width="200" height="160" alt="cocodrilo" />
        <img src="img/alostands.gif" id="alberto" class="alberto" width="127" height="200" alt="alberto" />
        <div id="puntajesD" class="puntajesD"><p id="puntaje">Puntaje: 0</p></p></div>
    </div>
</body>
</html>
