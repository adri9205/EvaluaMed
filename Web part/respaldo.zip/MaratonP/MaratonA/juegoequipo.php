<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<?php
session_start();
$id=$_SESSION['username'];
if(!isset($_SESSION['username'])){
	
	header("location:index.php");
	
}
?>
<html>
    <head>
    <link rel="stylesheet" href="../table.css" type="text/css"/>

<link rel="stylesheet" type="text/css" href="../Estilos.css">
<script language="Javascript" type="text/javascript" src="../validar.js"></script>
<script>
var clave= "";
var grupo= "";
var parcial="";
function ObtieneGrupos(str)
{
	 document.getElementById("Iniciar").innerHTML="";
	 document.getElementById("Parcial").innerHTML="";
	clave= str;
if (str=="")
  {
  document.getElementById("Grupos").innerHTML="";
  return;
  } 
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("Grupos").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","../ObtieneGrupos.php?q="+clave+ "&modo=8",true);
xmlhttp.send();
} 


function ObtieneIniciar(str)
{

parcial= str;
 document.getElementById("Iniciar").innerHTML="";
if (str=="")
  {
  document.getElementById("Iniciar").innerHTML="";
  return;
  } 
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("Iniciar").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","../ObtieneValidacionJuego.php?modo=2"+"&clave="+clave+"&grupo="+grupo+"&parcial="+parcial,true);
xmlhttp.send(); 
}

function ObtieneParcial(str)
{
	grupo= str;
	 document.getElementById("Iniciar").innerHTML="";
	
	
if (str=="")
  {
  document.getElementById("Parcial").innerHTML="";
  return;
  } 
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("Parcial").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","../ObtieneValidacionJuego.php?clave="+clave+ "&grupo="+grupo+"&modo=3",true);
xmlhttp.send();
}
</script>
        <title>Manda datos</title>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
      <?php
   
		$conexion=mysqli_connect("localhost","root","","basemaraton");
		
		if (mysqli_connect_errno($conexion))
		  {
		  echo "No se puedo conectar a la base de datos: " . mysqli_connect_error();
		  }
		$resultado=mysqli_query($conexion,"select DISTINCT Clave from grupo where Maestro='$id'");	
		
		$result2=mysqli_query($conexion,"select * from maestro t WHERE t.Nomina = '".  $id ."' AND t.Administrador=1") or die(mysqli_error());
	$result3=mysqli_query($conexion,"select * from maestro t WHERE t.Nomina = '".  $id ."' AND t.Administrador=0") or die(mysqli_error());
	$result4=mysqli_query($conexion,"select * from alumno t WHERE t.Matricula = '".  $id ."'") or die(mysqli_error());
	
	
			while($row = mysqli_fetch_array($result2)) {
			include("MenuMaestroAdmin.html"); 
	  
	} 
	while($row = mysqli_fetch_array($result3)) {
			include("MenuMaestro.html"); 
	  
	} 
	while($row = mysqli_fetch_array($result4)) {
			include("MenuAlumno.html"); 
	  
	} 
	?>
    <div class="CSS_Table_Example" style="width:600px;height:150px;" align="center">


        <form name="input" action="juego_equipo.php" method="POST">
        <table class="CSS_Table_Example" align="center" width="69%" border="">
         <tr>
      <td colspan="4" scope="col">Ingresar Materia: </td>
    </tr>
      
       <tr> <td>Clave:</td><td><select name="clave" id="clave" class="req" onchange="ObtieneGrupos(this.value)">
	<option selected>--</option>
	<?php
		while($row=mysqli_fetch_array($resultado)){
		$ClaveAl=$row["Clave"];
			$NombreMateria=mysqli_query($conexion,"select * from clase WHERE Clave='$ClaveAl'") or die(mysqli_error());
			$row2=mysqli_fetch_array($NombreMateria);
		print("<option value=".$row["Clave"].">".$row["Clave"]." ".$row2["Nombre"]."</option>");
		}
	?>
	</select><span></span></td></tr>
     <tr><td>Grupo: </td>
      <td><div id="Grupos"></div></td>
    </tr>
     <tr><td>Parcial</td>
      <td><div id="Parcial"></div></td>

    </tr>
        <tr>  <td></td><td>
        
       <div id="Iniciar"> </div> 
        
        </td>
        </tr>
        </table> </form>
       </div>
    </body>
</html>