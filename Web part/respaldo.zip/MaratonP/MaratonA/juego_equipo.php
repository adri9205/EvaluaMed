<!--
juego_equipo.php es la base del juego en equipos
Año de elaboración: 2013
Equipo desarrollador:
Ricardo Molina
Javier Yépiz
Daniel Garza
Erasmo Leal
-->
<!DOCTYPE html>
<?php
session_start();
$usuario = $_SESSION['username'];
if (!isset($_SESSION['username'])) {

    header("location:../index.php");
}
?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Juego Maraton Equipo</title>
        <link rel="stylesheet" type="text/css" href="css_equipo.css">
        <script src="jquery-1.10.2.js"></script>
        <script src="script_equipo.js"></script>

    </head>
    <?php
    $clave = $_POST['clave'];
    $grupo = $_POST['grupo'];
    $parcial = $_POST['parcial'];
    echo "<body onload='inicio(\"" . $clave . "\"," . $grupo . "," . $parcial . ")' class='ty'>";
    ?>
    <div id="pregunta"></div>
    <div class="imagen" id="fondo">

    </div>
</body>
</html>
