<?php
session_start();
$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))||(($_SESSION['username']!="admin")&&($_SESSION['username']!="evaluador")&&($_SESSION['username']!="alumno"))){
	
	header("location:default.html");
	
}

include 'configuration.php';

		$password 		= $_GET['password'];
		$password_c 		= $_GET['password_c'];
		
		if($_SESSION['username']=="admin"){

			mysql_query("UPDATE `administrador` SET `password`='".$password."' WHERE `id_administrador`='".$id."'") or die();
			
			$result=mysql_query("SELECT * FROM `administrador`") or die(mysql_error()); 
			
			$row = mysql_fetch_array($result);
			
			$to = $row['correo'];
		
		}
		else if($_SESSION['username']=="evaluador"){
		
			mysql_query("UPDATE `evaluadores` SET `password`='".$password."' WHERE `id_evaluadores`='".$id."'") or die();
			
			$result=mysql_query("SELECT * FROM `evaluadores` WHERE `id_evaluadores`='".$id."'") or die(mysql_error());
			
			$row = mysql_fetch_array($result); 
			
			$to = $row['id_evaluadores'];
		
		
		}
		else{
		
			mysql_query("UPDATE `alumnos` SET `password`='".$password."' WHERE `id_alumno`='".$id."'") or die();
			
			$result=mysql_query("SELECT * FROM `alumnos` WHERE `id_alumno`='".$id."'") or die(mysql_error()); 
			
			$row = mysql_fetch_array($result);
			
			$to = $row['id_alumno'];
			$to = $to."@itesm.mx";
		
		
		}
		

				$subject = "Cambio Contrase&ntilde;a";
				
				$message = "
				<html>
				<head>
				<title>Cambio Contrase&ntilde;a</title>
				</head>
				<body>
				<p>Equipo EvaluaMed:</p>
				<p>Se ha cambiado la contrase&ntilde;a del usuario. A continuaci&oacute;n se despliega la informaci&oacute;n.</p>
				<table>
				<tr>
				<td>Correo:</td><td>".$row['correo']."</td>
				</tr>
				<tr>
				<td>Contrase&ntilde;a:</td><td>".$row['password']."</td>
				</tr>
				</table>
				<p>Este mensaje es autom&aacute;tico favor de no contestar.</p>
				</body>
				</html>
				";
				
				// Always set content-type when sending HTML email
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				
				// More headers
				$headers .= 'From: <mensajes@evaluacionqx.com>' . "\r\n";

				
				mail($to,$subject,$message,$headers);
		
		$respuesta = 1;
		
		// Se manda el nombre del equipo
		echo $respuesta;


	?>