<?php

$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))&&($_SESSION['username']=="admin")){
	
	header("location:default.html");
	
}

include 'configuration.php';

		$id_especialidad 		= $_GET['especialidad'];
		
		
		
			$result=mysql_query("select * from `grupos` a WHERE a.id_especialidad = '".$id_especialidad."' ORDER BY nivel ASC") or die(mysql_error()); 
			
			$result2=mysql_query("SELECT * FROM `especialidad` a WHERE a.id_especialidad = '".$id_especialidad."' ") or die(mysql_error());
			
		
		

	$row = mysql_fetch_array($result);
	$row2 = mysql_fetch_array($result2);
	if($row != NULL){
		
	echo " <p></p>";
	echo "	<table class='as_gridder_table'>";
        echo "    <tr class='grid_header'>";
        echo "        <td>Especialidad</td>";
        echo "        <td>Nivel</td>";
        echo "        <td>Titular</td>";
               
        echo "    </tr>";
        
        do{
        
        
        echo "    <tr style='background-color:#FFFFFF'>";
                  
        echo "            <td>".$row2['nombre']."</td>";
        
        if($row['nivel'] == '1')
        	echo "            <td>R1</td>";
        else if($row['nivel'] == '2')
        	echo "            <td>R2</td>";
        else if($row['nivel'] == '3')
        	echo "            <td>R3</td>";
        else if($row['nivel'] == '4')
        	echo "            <td>R4</td>";
        else
        	echo "            <td>R5</td>";
        	
        echo "<td><select name='titular' id='titular' class='gridder_add select' onchange='dbgrupo(this.value)'>";
	echo "<option value=";
	echo $row['nivel'];
	echo ">Grupo Sin Maestro Titular</option>";
	
                        $result3=mysql_query("select * from evaluadores ") or die(mysql_error());
                   while($row3 = mysql_fetch_array($result3))  { 
        echo "                <option value=";
                        
                        if($row['id_titular'] ==  $row3['id_evaluadores']){
                        
                         echo $row['nivel'].$row3['id_evaluadores']." selected='selected'>";
                         
                         }
                         else{
                         
                          echo  $row['nivel'].$row3['id_evaluadores'].">";
                         
                         }  echo $row3['nombre']." ".$row3['apellido_p']." ".$row3['apellido_m']." ".$row3['id_evaluadores']." </option>";
                         } 
                        $result3=mysql_query("select * from evaluadores ") or die(mysql_error());
        echo "</select></td>";
                    
                   
                    
	echo "			</tr>";
				
		}while($row = mysql_fetch_array($result)); 
         echo "       </table>";
						
	}  
	
	else {
		
		echo "<p> No se encontr&oacute; alg&uacute;n alumno con esos datos. </p>";

	}
?>