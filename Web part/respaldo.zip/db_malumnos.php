<!DOCTYPE html>
<?php
session_start();
$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))||($_SESSION['username']!="admin")){
	
	header("location:default.html");
	
}

include("MenuSuperAdmin.html");
include 'configuration.php';

$matricula 		= $_GET['id'];

$result=mysql_query("select * from alumnos a WHERE a.id_alumno = '".$matricula."' ") or die(mysql_error()); 

$row = mysql_fetch_array($result);
	?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lista Alumnos</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="table.css" type="text/css"/>
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link href="textos.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<script src="jquery-1.10.2.js"></script>
<script>

function dbalumno() {

	var result= 0;

	document.getElementById("error").innerHTML = "";
	
	var matricula= document.getElementById('matricula').innerHTML;
	var nombre = document.getElementById('nombre').value;
	var apaterno = document.getElementById('apaterno').value;
	var amaterno = document.getElementById('amaterno').value;
	var nivel = document.getElementById('nivel').value;
	var especialidad = document.getElementById('especialidad').value;
	
	if((matricula!="")&&(nombre!="")&&(apaterno!="")&&(amaterno!="")&&(nivel!=0)&&(especialidad!=0)){
	
	    $.ajax({
	           type: 'GET',
	            url : 'modificar_alumno.php',
	            async: false,
	            data: {matricula: matricula, nombre: nombre, apaterno: apaterno, amaterno: amaterno, nivel: nivel, especialidad: especialidad},
	            success: function(resultado) {
	                result = resultado;
	            }
	        });
	        
	        if(result == 1){
	        
	        	document.getElementById("estatus").innerHTML = "<img src='images/checkmark.png' />";
	        	document.getElementById("mensaje").innerHTML = "CAMBIOS GUARDADOS";
	        }
	        
	        else{
	        
	        	document.getElementById("estatus").innerHTML = "<img src='images/alerta.png' />";
	        	document.getElementById("mensaje").innerHTML = "ERROR EN LA BASE DE DATOS";
	        
	        }
	        
	        }
	        else{
	        
	        	document.getElementById("error").innerHTML = "Completar todos los campos";
	        }
	
}

function borrar() {

	var result= 0;

	var matricula= document.getElementById('matricula').innerHTML;

	var confirmacion = confirm("Borrar alumno con matricula "+matricula+"?");
	
	if(confirmacion){
	
		 $.ajax({
	           type: 'GET',
	            url : 'borrar_alumno.php',
	            async: false,
	            data: {matricula: matricula},
	            success: function(resultado) {
	                result = resultado;
	            }
	        });
	
		if(result == 1){
		
		document.getElementById('Login').submit();
		
		}
		else{
			alert("Error en la base de datos");
			
		}
	}

}
</script>
</head>
<body>
<h3>Editar datos del alumno</h3>
<div>
<div class="formulario">
<form action='borrar_regreso.php' method='post' id='Login'>
        <p>Matricula:</p>
        <?php
        echo "<p id='matricula' name='matricula' value='".$row['id_alumno']."'>".$row['id_alumno']."</p>";
        ?>
        <p>Nombre(s):</p>
       <?php
        echo "<input type='text' id='nombre' name='nombre' value='".$row['nombre']."' />";
        ?>
        <br>
        <p>Apellido Paterno:</p>
        <?php
        echo "<input type='text' id='apaterno' name='apaterno' value='".$row['apellido_p']."' />";
        ?>
        <br>
        <p>Apellido Materno:</p>
        <?php
        echo "<input type='text' id='amaterno' name='amaterno' value='".$row['apellido_m']."' />";
        ?>
        <br>
        <p>A&ntilde;o:</p>
        <select id="nivel">
        <?php
        $i = 0;
        echo "    <option value='0'>Seleccionar</option>";
        $i = $i + 1;
        if($i == $row['nivel'])
	    	echo "<option value='1' selected='selected'>R1</option>";
	else
		echo "<option value='1'>R1</option>";
	$i = $i + 1;
        if($i == $row['nivel'])
	    	echo "<option value='2' selected='selected'>R2</option>";
	else
		echo "<option value='2'>R2</option>";
		$i = $i + 1;
        if($i == $row['nivel'])
	    	echo "<option value='3' selected='selected'>R3</option>";
	else
		echo "<option value='3'>R3</option>";
		$i = $i + 1;
        if($i == $row['nivel'])
	    	echo "<option value='4' selected='selected'>R4</option>";
	else
		echo "<option value='4'>R4</option>";
		$i = $i + 1;
        if($i == $row['nivel'])
	    	echo "<option value='5' selected='selected'>R5</option>";
	else
		echo "<option value='5'>R5</option>";	
	    ?>
	</select>
	<br>
	<p>Especialidad:</p>
	<select name="especialidad" id="especialidad" class="gridder_add select">
	<option value="0">Seleccionar</option>
	<?php 
                        $result2=mysql_query("select * from especialidad ") or die(mysql_error());?>
                   <?php while($row2 = mysql_fetch_array($result2))  { ?>
                        <option value=<?php
                        
                        if($row2['nombre'] ==  $row['especialidad']){
                        
                         echo $row2['nombre']." selected='selected'";
                         
                         }
                         else{
                         
                          echo $row2['nombre'];
                         
                         } ?>><?php echo $row2["nombre"]; ?></option>
                        <?php } 
                        $result2=mysql_query("select * from especialidad ") or die(mysql_error());?>
        </select>
	<br>
	<button type="button" class="eliminar" onclick="borrar()">Eliminar Alumno</button>
  	<button type="button" class="base" onclick="dbalumno()">Guardar Cambios</button>
	<br>
	<p id="error" class="error"></p>
	</form>
</div>
<div class="salida" id="salida">
<p id="estatus"></p>
<p id="mensaje"></p>
</div>
</div>
</body>
</html>