<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<?php
session_start();
$id=$_SESSION['username'];
if(!isset($_SESSION['username'])){
	
	header("location:default.html");
	
}
	?>
<!-- Arvhivo encargado de iniciar sesion -->
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link rel="stylesheet" href="table.css" type="text/css"/>
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="script.js"></script>
<script language="Javascript" type="text/javascript" src="validar.js">
</script>
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>

<?php  

$conexion=mysql_connect("localhost","evaluac4_equipo","equipo2222*");
mysql_select_db("evaluac4_base",$conexion);


function getRandomCode(){
    $an = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-)(.:,;";
    $su = strlen($an) - 1;
    return substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1);
}

	$correo=$_POST["correo"];
	$nombre=$_POST["nombre"];
	$apaterno=$_POST["apaterno"];
	$amaterno=$_POST["amaterno"];
	$especialidad=$_POST["especialidad"];
	$codigo=getRandomCode();
	$password=getRandomCode();
	$titular='1';
	
	
			$result=mysql_query("select id_evaluadores from evaluadores a WHERE a.id_evaluadores = '".$correo."' ", $conexion) or die(mysql_error()); 
			
			if($row = mysql_fetch_array($result) != NULL){
				header("location:volver_intentar.php");

			}  
			else{
			
				mysql_query("INSERT INTO evaluadores VALUES ('$correo','$nombre','$apaterno','$amaterno','$password','$titular','$especialidad','$codigo')", $conexion) or die(mysql_error());
				
					$to = $correo;
					$subject = "Solicitud aceptada";
					
					$message = "
					<html>
					<head>
					<title>Solicitud aceptada</title>
					</head>
					<body>
					<p>Equipo EvaluaMed:</p>
					<p>Se ha aceptado su solicitud de creación de cuenta como evaluador. A continuaci&oacute;n se despliega su informaci&oacute;n.</p>
					<table>
					<tr>
					<td>Correo:</td><td>".$correo."</td>
					</tr>
					<tr>
					<tr>
					<td>Contraseña:</td><td>".$password."</td>
					</tr>
					</table>
					<p>Apartir de este momento puede ingresar al sistema y a la aplicación móvil con su cuenta y contraseña.</p>
					
					<p>Este mensaje es autom&aacute;tico favor de no contestar.</p>
					</body>
					</html>
					";
					
					// Always set content-type when sending HTML email
					$headers = "MIME-Version: 1.0" . "\r\n";
					$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
					
					// More headers
					$headers .= 'From: <mensajes@evaluacionqx.com>' . "\r\n";
	
					
					mail($to,$subject,$message,$headers);
				
				}
							
			
			
			?>
		
</head>
<body>
    <h1>EvaluaMed</h1>
            
  <div class="login-block">

      <h3>Solicitud aceptada.</h3>
    
    <input type="button" onClick=" window.location.href='MenuSuperAdmin.html'"   value="Regresar">
    
</div>
    </body>
</html>