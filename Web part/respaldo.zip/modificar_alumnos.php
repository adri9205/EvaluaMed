<!DOCTYPE html>
<?php
session_start();
$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))||($_SESSION['username']!="admin")&&($_SESSION['username']!="evaluador")){
	
	header("location:default.html");
	
}
if($_SESSION['username']=="admin")
include("MenuSuperAdmin.html");
else
include("MenuMaestro.html");
include 'configuration.php';
	?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lista Alumnos</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="table.css" type="text/css"/>
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link href="textos.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<script src="jquery-1.10.2.js"></script>
<script>


function dbalumno() {

	document.getElementById("error").innerHTML = "";
	
	var matricula= document.getElementById("matricula").value;
	var nombre = document.getElementById("nombre").value;
	var apaterno = document.getElementById("apaterno").value;
	var amaterno = document.getElementById("amaterno").value;
	var nivel = document.getElementById("nivel").value;
	var especialidad = document.getElementById("especialidad").value;
	
	if((matricula!="")||(nombre!="")||(apaterno!="")||(amaterno!="")||(nivel!=0)||(especialidad!=0)){
	
		document.getElementById("salida").innerHTML = "";
	        if (window.XMLHttpRequest)
	        {// code for IE7+, Firefox, Chrome, Opera, Safari
	            xmlhttp = new XMLHttpRequest();
	        }
	        else
	        {// code for IE6, IE5
	            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	        }
	        xmlhttp.onreadystatechange = function()
	        {
	            if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
	            {
	                document.getElementById("salida").innerHTML = xmlhttp.responseText;
	            }
	        }
	
	        //Manda comoo argumentos la clave, el numero de pregunta y el orden
	        xmlhttp.open("GET", "busca_alumnos_modificar.php?matricula=" + matricula + "&nombre=" + nombre + "&apaterno=" + apaterno + "&amaterno=" + amaterno + "&nivel=" + nivel + "&especialidad=" + especialidad, true);
	        xmlhttp.send();
	        
	        }
	        else{
	        
	        	document.getElementById("error").innerHTML = "Campos vac&iacute;os";
	        }
	
}

function limpiar() {

	document.getElementById("matricula").value="";
	document.getElementById("nombre").value="";
	document.getElementById("apaterno").value="";
	document.getElementById("amaterno").value="";
	document.getElementById("nivel").value=0;
	document.getElementById("especialidad").value=0;
	document.getElementById("estatus").innerHTML = "";
	document.getElementById("mensaje").innerHTML = "";
	document.getElementById("error").innerHTML = "";

}
function checkSubmit(e)
{
   if(e && e.keyCode == 13)
   {
      dbalumno();
   }
}
</script>
</head>
<body style="background-color:lightgrey">
<h3>Ingrese los datos para la b&uacute;squeda del alumno</h3>
<div>
<div class="formulario" onKeyPress="return checkSubmit(event)">
        <p>Matricula (con A0):</p>
        <input type="text" id="matricula" name="matricula">
        <br>
        <p>Nombre(s):</p>
        <input type="text" id="nombre" name="nombre">
        <br>
        <p>Apellido Paterno:</p>
        <input type="text" id="apaterno" name="apaterno">
        <br>
        <p>Apellido Materno:</p>
        <input type="text" id="amaterno" name="amaterno">
        <br>
        <p>A&ntilde;o:</p>
        <select id="nivel">
            <option value="0">Seleccionar</option>
	    <option value="1">R1</option>
	    <option value="2">R2</option>
	    <option value="3">R3</option>
	    <option value="4">R4</option>
	    <option value="5">R5</option>
	</select>
	<br>
	<p>Especialidad:</p>
	<select name="especialidad" id="especialidad" class="gridder_add select">
	<option value="0">Seleccionar</option>
	<?php 
                        $result=mysql_query("select * from especialidad ") or die(mysql_error());?>
                   <?php while($row = mysql_fetch_array($result))  { ?>
                        <option value="<?php echo $row['nombre']; ?>"><?php echo $row["nombre"]; ?></option>
                        <?php } 
                        $result=mysql_query("select * from especialidad ") or die(mysql_error());?>
        </select>
	<br>
	<button type="button" class="limpiar" onclick="limpiar()">Limpiar Campos</button>
  	<button type="button" class="base" onclick="dbalumno()">Buscar Alumno</button>
	<br>
	<p id="error" class="error"></p>
</div>
<div class="salida" id="salida">
</div>
</div>
</body>
</html>