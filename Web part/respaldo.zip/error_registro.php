<!DOCTYPE html>
<html>
    <head>
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link rel="stylesheet" href="table.css" type="text/css"/>

        
    </head>
    <body>
    <h1>EvaluaMed</h1>
            
  <div class="login-block">

      <h3>Usuario ya existente</h3>
      <h3>Ingrese un correo electr&oacute;nico v&aacute;lido</h3>
   
    <input type="button" onClick=" window.location.href='default.html'"   value="Regresar">
    
</div>
    </body>
</html>