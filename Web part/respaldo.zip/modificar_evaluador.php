<!DOCTYPE html>
<?php
session_start();
$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))&&($_SESSION['username']=="admin")){
	
	header("location:default.html");
	
}

include("MenuSuperAdmin.html");
include 'configuration.php';
	?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lista Alumnos</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="table.css" type="text/css"/>
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link href="textos.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<script src="jquery-1.10.2.js"></script>
<script>


function dbevaluador() {

	document.getElementById("error").innerHTML = "";
	
	var correo= document.getElementById("correo").value;
	var nombre = document.getElementById("nombre").value;
	var apaterno = document.getElementById("apaterno").value;
	var amaterno = document.getElementById("amaterno").value;
	var especialidad = document.getElementById("especialidad").value;
	var titular = document.getElementById("titular").value;
	
	if((correo!="")||(nombre!="")||(apaterno!="")||(amaterno!="")||(especialidad!="")||(titular!=2)){
	
		document.getElementById("salida").innerHTML = "";
	        if (window.XMLHttpRequest)
	        {// code for IE7+, Firefox, Chrome, Opera, Safari
	            xmlhttp = new XMLHttpRequest();
	        }
	        else
	        {// code for IE6, IE5
	            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	        }
	        xmlhttp.onreadystatechange = function()
	        {
	            if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
	            {
	                document.getElementById("salida").innerHTML = xmlhttp.responseText;
	            }
	        }
	
	        //Manda comoo argumentos la clave, el numero de pregunta y el orden
	        xmlhttp.open("GET", "busca_evaluador_modificar.php?correo=" + correo + "&nombre=" + nombre + "&apaterno=" + apaterno + "&amaterno=" + amaterno + "&especialidad=" + especialidad+ "&titular=" + titular, true);
	        xmlhttp.send();
	        
	        }
	        else{
	        
	        	document.getElementById("error").innerHTML = "Campos vac&iacute;os";
	        }
	
}

function limpiar() {

	document.getElementById("correo").value="";
	document.getElementById("nombre").value="";
	document.getElementById("apaterno").value="";
	document.getElementById("amaterno").value="";
	document.getElementById("especialidad").value="";
	document.getElementById("titular").value=2;
	document.getElementById("estatus").innerHTML = "";
	document.getElementById("mensaje").innerHTML = "";
	document.getElementById("error").innerHTML = "";

}
function checkSubmit(e)
{
   if(e && e.keyCode == 13)
   {
      dbevaluador();
   }
}
</script>
</head>
<body style="background-color:lightgrey">
<h3>Ingrese los datos para la b&uacute;squeda del evaluador</h3>
<div>
<div class="formulario" onKeyPress="return checkSubmit(event)">
        <p>Correo electr&oacute;nico:</p>
        <input type="text" id="correo" name="correo">
        <br>
        <p>Nombre(s):</p>
        <input type="text" id="nombre" name="nombre">
        <br>
        <p>Apellido Paterno:</p>
        <input type="text" id="apaterno" name="apaterno">
        <br>
        <p>Apellido Materno:</p>
        <input type="text" id="amaterno" name="amaterno">
        <br>
        <p>Especialidad:</p>
        <input type="text" id="especialidad" name="especialidad">
        <br>
        <p>Estatus:</p>
        <select id="titular">
            <option value="2">Seleccionar</option>
	    <option value="1">Activo</option>
	    <option value="0">Inactivo</option>
	</select>
	<br>
	<br>
	<button type="button" class="limpiar" onclick="limpiar()">Limpiar Campos</button>
  	<button type="button" class="base" onclick="dbevaluador()">Buscar Evaluador</button>
	<br>
	<p id="error" class="error"></p>
</div>
<div class="salida" id="salida">
</div>
</div>
</body>
</html>