<!DOCTYPE html>
<?php
session_start();
$id=$_SESSION['cookie1'];
if(!isset($_SESSION['username'])){
	
	header("location:default.html");
	
}
	?>
<html>

<head>
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link rel="stylesheet" href="table.css" type="text/css"/>
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="script.js"></script>
<script language="Javascript" type="text/javascript" src="validar.js">
</script>
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<?php



	if (!($conexion=mysql_connect("localhost","evaluac4_equipo","equipo2222*")))
	{
		echo "Error conectando a la base de datos.";
		exit();
	}
	if (!mysql_select_db("evaluac4_base",$conexion))
	{
		echo "Error seleccionando la base de datos.";
		exit();
	}
	
	
	$result=mysql_query("select * from alumnos t WHERE t.id_alumno = '".  $id ."'", $conexion) or die(mysql_error()); 
	$result2=mysql_query("select * from evaluadores t WHERE t.id_evaluadores = '".  $id ."'", $conexion) or die(mysql_error());
	$result3=mysql_query("select * from administrador t WHERE t.id_administrador = '".  $id ."'", $conexion) or die(mysql_error()); 
	
	while($row = mysql_fetch_array($result)) {
			include("MenuAlumno.html"); 
			$id=$row["id_alumno"];
			$contrasenia=$row["password"];
	}
			
	while($row = mysql_fetch_array($result2)) {
			include("MenuMaestro.html"); 
			$id=$row["id_evaluadores"];
	   		$contrasenia=$row["password"];
		
	}  
	
	while($row = mysql_fetch_array($result3)) {
			include("MenuSuperAdmin.html"); 
			$id=$row["id_administrador"];
			$contrasenia=$row["password"];
	} 
		
?> 
<title>Inicio</title>
<meta http-equiv="Content-Type" content="text/html; charset=shift_jis">
</head>

<body>

</body> 
</html>