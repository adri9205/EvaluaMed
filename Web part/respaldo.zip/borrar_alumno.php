<?php

$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))&&($_SESSION['username']=="admin")){
	
	header("location:default.html");
	
}

include 'configuration.php';

		$matricula 		= $_GET['matricula'];


		mysql_query("DELETE FROM `alumnos` WHERE `id_alumno`='".$matricula."'") or die();
		
		$respuesta = 1;
		
		// Se manda el nombre del equipo
		echo $respuesta;
	?>