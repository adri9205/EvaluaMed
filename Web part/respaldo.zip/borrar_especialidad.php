<?php

$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))&&($_SESSION['username']=="admin")){
	
	header("location:default.html");
	
}

include 'configuration.php';

		$id_especialidad 		= $_GET['id_especialidad'];

		mysql_query("DELETE FROM especialidad WHERE id_especialidad='".$id_especialidad."'") or die();
		
		mysql_query("DELETE FROM `grupos` WHERE id_especialidad='".$id_especialidad."'") or die();
		
		mysql_query("DELETE FROM `grupos` WHERE id_especialidad='".$id_especialidad."'") or die();
		
		mysql_query("DELETE FROM `grupos` WHERE id_especialidad='".$id_especialidad."'") or die();
		
		mysql_query("DELETE FROM `grupos` WHERE id_especialidad='".$id_especialidad."'") or die();
		
		mysql_query("DELETE FROM `grupos` WHERE id_especialidad='".$id_especialidad."'") or die();

	?>