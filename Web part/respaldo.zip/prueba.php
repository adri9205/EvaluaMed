<?php

$mysqli = new mysqli("localhost", "evaluac4_equipo", "equipo2222*", "evaluac4_base", 3306);
if ($mysqli->connect_errno) {
    echo "Fallo al conectar a MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
}

echo $mysqli->host_info . "\n";
?>