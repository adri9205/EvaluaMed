<?php
$host 		= "localhost"; // Your hostname
$username	= "evaluac4_equipo"; // Your host username
$password	= "equipo2222*"; // Your host password
$db			= "evaluac4_base"; // Your database name
mysql_connect($host, $username, $password) or die("Oops! Coudn't connect to server"); // Connect to the server
mysql_select_db($db) or die("Oops! Coudn't select Database"); // Select the database
?>