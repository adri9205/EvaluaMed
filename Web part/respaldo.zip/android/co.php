<?php
$to = "adri925@hotmail.com,"."adri925@gmail.com";
$subject = "My subject";
$txt = "Hello world!";

mail($to,$subject,$txt);
?>