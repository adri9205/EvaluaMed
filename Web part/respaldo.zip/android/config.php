<?php
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "evaluac4_equipo");//cambiar por el nombre de usuario definido en la configuracion de la BD.
define("DB_PASSWORD", "equipo2222*");//Modificar por el password elegido
define("DB_DATABASE", "evaluac4_base");//Nombre de la base de datos reemplazar si se utilizo otro diferente al mencionado en el tutorial.
?>
