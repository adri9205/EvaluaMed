<!DOCTYPE html>
<?php
session_start();
$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))&&($_SESSION['username']=="admin")){
	
	header("location:default.html");
	
}

include("MenuSuperAdmin.html");
include 'configuration.php';

$nombre=$_POST["nombre"];
$apaterno=$_POST["apaterno"];
$amaterno=$_POST["amaterno"];

	?>
<html>
    <head>
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link rel="stylesheet" href="table.css" type="text/css"/>

        
    </head>
    <body style="background-color:lightgrey">
            
  <div>

<h3>Alumno con nombre <?php echo $nombre." ".$apaterno." ".$amaterno." borrado";?></h3>

	<h3><a href="http://evaluacionqx.com/modificar_alumnos.php">Regresar</a></h3>
   

    
</div>
    </body>
</html>