<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- Arvhivo encargado de iniciar sesion -->
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link rel="stylesheet" href="table.css" type="text/css"/>
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="script.js"></script>
<script language="Javascript" type="text/javascript" src="validar.js">
</script>
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>

<?php  

	$conexion=mysql_connect("localhost","evaluac4_equipo","equipo2222*");
	mysql_select_db("evaluac4_base",$conexion);

	$correo=$_POST["correo"];
	$liga='window.location.href="default.html"';
	
	
		
			$result=mysql_query("select * from evaluadores a WHERE a.id_evaluadores = '".$correo."' ", $conexion) or die(mysql_error()); 
			$result2=mysql_query("select *  from alumnos a WHERE a.id_alumno = '".$correo."'", $conexion) or die(mysql_error()); 
			
			$row = mysql_fetch_array($result);
			
			$row2 = mysql_fetch_array($result2);
			
			if($row != NULL){
			
				$to = $correo;
				$subject = "Recuperar contraseña";
				
				$message = "
				<html>
				<head>
				<title>Solicitud de recuperación de contraseña</title>
				</head>
				<body>
				<p>Equipo EvaluaMed:</p>
				<p>Se ha recibido una solicitud para recuperar contraseña. A continuaci&oacute;n se despliega la informaci&oacute;n proporcionada del usuario.</p>
				<table>
				<tr>
				<td>Correo:</td><td>".$correo."</td>
				</tr>
				<tr>
				<td>Contraseña:</td><td>".$row["password"]."</td>
				</tr>
				</table>
				<p>Este mensaje es autom&aacute;tico favor de no contestar.</p>
				</body>
				</html>
				";
				
				// Always set content-type when sending HTML email
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				
				// More headers
				$headers .= 'From: <mensajes@evaluacionqx.com>' . "\r\n";

				
				mail($to,$subject,$message,$headers);
				
				echo "</head>";
				echo "<body>";
				echo "    <h1>EvaluaMed</h1>";
				echo "            <br>";
				echo "  <div class='login-block'>";
				
				echo "      <h3>Correo enviado a '".$correo."'</h3>";
				    
				echo "    <input type='button' onClick='".$liga."'   value='Regresar'>";
				    
				echo "</div>";
				echo "    </body>";
				echo "</html>";

			}  
			else if($row2 != NULL){
			
				$to = $correo."@itesm.mx";
				$subject = "Recuperar contraseña";
				
				$message = "
				<html>
				<head>
				<title>Solicitud de recuperación de contraseña</title>
				</head>
				<body>
				<p>Equipo EvaluaMed:</p>
				<p>Se ha recibido una solicitud para recuperar contraseña. A continuaci&oacute;n se despliega la informaci&oacute;n proporcionada del usuario.</p>
				<table>
				<tr>
				<td>Correo:</td><td>".$correo."</td>
				</tr>
				<tr>
				<td>Contraseña:</td><td>".$row["password"]."</td>
				</tr>
				</table>
				<p>Este mensaje es autom&aacute;tico favor de no contestar.</p>
				</body>
				</html>
				";
				
				// Always set content-type when sending HTML email
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				
				// More headers
				$headers .= 'From: <mensajes@evaluacionqx.com>' . "\r\n";

				
				mail($to,$subject,$message,$headers);
				
				echo "</head>";
				echo "<body>";
				echo "    <h1>EvaluaMed</h1>";
				echo "            <br>";
				echo "  <div class='login-block'>";
				
				echo "      <h3>Correo enviado a '".$correo."'@itesm.mx</h3>";
				    
				echo "    <input type='button' onClick='".$liga."'   value='Regresar'>";
				    
				echo "</div>";
				echo "    </body>";
				echo "</html>";

			}
			else{
			
				echo "</head>";
				echo "<body>";
				echo "    <h1>EvaluaMed</h1>";
				echo "            <br>";
				echo "  <div class='login-block'>";
				
				echo "      <h3>Usuario inv&aacute;lido</h3>";
				    
				echo "    <input type='button' onClick='".$liga."'   value='Regresar'>";
				    
				echo "</div>";
				echo "    </body>";
				echo "</html>";
							
			}
			
			?>