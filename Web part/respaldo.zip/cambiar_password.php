<!DOCTYPE html>
<?php
session_start();
$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))||(($_SESSION['username']!="admin")&&($_SESSION['username']!="evaluador")&&($_SESSION['username']!="alumno"))){
	
	header("location:default.html");
	
}

if($_SESSION['username']=="admin")
include("MenuSuperAdmin.html");
else if($_SESSION['username']=="evaluador")
include("MenuMaestro.html");
else
include("MenuAlumno.html");
include 'configuration.php';
	?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lista Alumnos</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="table.css" type="text/css"/>
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link href="textos.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<script src="jquery-1.10.2.js"></script>
<script>

function cambiarpassword() {

	document.getElementById("error").innerHTML = "";

	var result=0;
	
	var password= document.getElementById("password").value;
	var password_c= document.getElementById("password_c").value;
	
	if((password!="")||(password_c!="")){
	
		if(password==password_c){
		
			
		    $.ajax({
		           type: 'GET',
		            url : 'db_password.php',
		            async: false,
		            data: {password:password, password_c:password_c},
		            success: function(resultado) {
		                result = resultado;
		            }
		        });
		        
		         document.getElementById("password").value="";
		         document.getElementById("password_c").value="";
		         
		         if(result==1)
		         	alert("Cambios Guardados");
		         else
		         	alert("Opps Error en la base de datos");
		}
		else{
			document.getElementById("error").innerHTML = "Contrase&ntilde;as no coinciden";
			
		}
	
	}
	else{
		document.getElementById("error").innerHTML = "Los campos no pueden estar vacios";
		
	}
	
}


function checkSubmit(e)
{
   if(e && e.keyCode == 13)
   {
      cambiarpassword();
   }
}
</script>
</head>
<body style="background-color:lightgrey">
<h3>Cambiar Contrase&ntilde;a</h3>
<div>
<div class="formulario" onKeyPress="return checkSubmit(event)">
        <p>Nueva Contrase&ntilde;a:</p>
        <input type="password" id="password" name="password">
        <br>
        <p>Confirmar Contrase&ntilde;a:</p>
        <input type="password" id="password_c" name="password_c">
        <br>
        <br>
        <p></p>
  	<button type="button" class="base" onclick="cambiarpassword()">Cambiar Contrase&ntilde;a</button>
	<br>
	<p id="error" class="error"></p>
</div>
<div class="salida" id="salida">
</div>
</div>
</body>
</html>