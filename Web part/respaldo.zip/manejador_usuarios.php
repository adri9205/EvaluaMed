<html>
<head>
<script src="script.js"></script>
<?php 
session_start(); 

$conexion=mysql_connect("localhost","evaluac4_equipo","equipo2222*");
mysql_select_db("evaluac4_base",$conexion);


	if(isset($_GET["id"])){
		$id= $_GET["id"];
	    $_SESSION['cookie1'] = $id;
	}else if(isset($_SESSION['cookie1']))
		$id = $_SESSION['cookie1'];
	else
		$id="";
	
	if(isset($_GET["password"])){
		$password = $_GET["password"];
		$_SESSION['cookie2']= $password;		
	}else if(isset($_SESSION['cookie2']))
		$password = $_SESSION['cookie2'];
	else
		$password="";
	
$result=mysql_query("select id_alumno, password from alumnos a WHERE a.id_alumno = '".$id."' AND a.password = '".$password."'", $conexion) or die(mysql_error()); 

		if($row = mysql_fetch_array($result) != NULL){
			$_SESSION['username']= "alumno";
			header( 'Location:Inicio.php' ) ;
		} else {
			$result=mysql_query("select id_evaluadores, password, titular from evaluadores a WHERE a.id_evaluadores = '".$id."' AND a.password = '".$password."' ", $conexion) or die(mysql_error()); 
			
			$row = mysql_fetch_array($result);
			
			if($row != NULL){
				
				$_SESSION['username']= "evaluador";
				header( 'Location:Inicio.php' ) ;
			}
			
			
			else{
						
					  $result=mysql_query("select id_administrador, password from administrador a WHERE a.id_administrador = '".$id."' AND a.password = '".$password."'", $conexion) or die(mysql_error()); 
					if($row = mysql_fetch_array($result) != NULL){
						$_SESSION['username']= "admin";
						 $_SESSION['cookie1'] = $id;
						header( 'Location:Inicio.php' ) ;
					}
					
					else{ 
						
					  	header( 'Location:ErrorLogin.php' ) ; 
					 
						}
					
					
				}
			}?>
		
</head>
<body>

					<table border="1" align="center">
					<tr>
						<td align="center">
						<p>Login incorrecto</p>
						<input type="button" value="Regresar" onClick="salir()">
						</td>
					</tr>
					</table>
                  

</body> 
</html>