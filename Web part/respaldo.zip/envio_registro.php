<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- Arvhivo encargado de iniciar sesion -->
<html>

<head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link rel="stylesheet" href="table.css" type="text/css"/>
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="script.js"></script>
<script language="Javascript" type="text/javascript" src="validar.js">
</script>
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>

<?php  

$conexion=mysql_connect("localhost","evaluac4_equipo","equipo2222*");
mysql_select_db("evaluac4_base",$conexion);


	$correo=$_POST["correo"];
	$nombre=$_POST["nombre"];
	$apaterno=$_POST["apaterno"];
	$amaterno=$_POST["amaterno"];
	$especialidad=$_POST["especialidad"];
	
	
		
			$result=mysql_query("select id_evaluadores from evaluadores a WHERE a.id_evaluadores = '".$correo."' ", $conexion) or die(mysql_error()); 
			$result2=mysql_query("select * from administrador ", $conexion) or die(mysql_error()); 
			
			if($row = mysql_fetch_array($result) != NULL){
				header("location:error_registro.php");

			}  
			else{
			
				$row = mysql_fetch_array($result2);
			
				$to = $row["correo"];
				$subject = "Solicitud de registro de evaluador";
				
				$message = "
				<html>
				<head>
				<title>Solicitud de registro de evaluador</title>
				</head>
				<body>
				<p>Equipo EvaluaMed:</p>
				<p>Se ha recibido una solicitud para un nuevo evaluador. A continuaci&oacute;n se despliega la informaci&oacute;n proporcionada por el usuario.</p>
				<table>
				<tr>
				<td>Correo:</td><td>".$correo."</td>
				</tr>
				<tr>
				<td>Nombre:</td><td>".$nombre."</td>
				</tr>
				<tr>
				<td>Apellido paterno:</td><td>".$apaterno."</td>
				</tr>
				<tr>
				<td>Apellido materno:</td><td>".$amaterno."</td>
				</tr>
				<tr>
				<td>Especialidad:</td><td>".$especialidad."</td>
				</tr>
				</table>
				<p>Para aceptar a este usuario dar click a la siguiente liga:</p>
				<a href='http://evaluacionqx.com/ingreso_evaluador.php?correo=".$correo."&nombre=".$nombre."&apaterno=".$apaterno."&amaterno=".$amaterno."&especialidad=".$especialidad."'>Click aqui</a>
				<p>Este mensaje es autom&aacute;tico favor de no contestar.</p>
				</body>
				</html>
				";
				
				// Always set content-type when sending HTML email
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				
				// More headers
				$headers .= 'From: <mensajes@evaluacionqx.com>' . "\r\n";

				
				mail($to,$subject,$message,$headers);
							
			}
			
			?>
		
</head>
<body>
    <h1>EvaluaMed</h1>
            <br>
  <div class="login-block">

      <h3>Solicitud de registro enviada</h3>
    
    <input type="button" onClick=" window.location.href='default.html'"   value="Regresar">
    
</div>
    </body>
</html>