<?php

$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))&&($_SESSION['username']=="admin")){
	
	header("location:default.html");
	
}

include 'configuration.php';

function getRandomCode(){
    $an = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-)(.:,;";
    $su = strlen($an) - 1;
    return substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1);
}

		$matricula 		= $_GET['matricula'];
		$nombre 		= $_GET['nombre'];
		$apellido_p 		= $_GET['apaterno'];
		$apellido_m 		= $_GET['amaterno'];
		$nivel 			= $_GET['nivel'];
		$especialidad 		= $_GET['especialidad'];
		$codigo			= getRandomCode();
		$codigo2		= getRandomCode();

	$result=mysql_query("select id_alumno from alumnos a WHERE a.id_alumno = '".$matricula."' ") or die(mysql_error()); 
	
	if($row = mysql_fetch_array($result) != NULL){
	
		$respuesta = 0;
		
						// Se manda el nombre del equipo
		echo $respuesta;
						
	}  
	
	else {
		mysql_query("INSERT INTO `alumnos`(`id_alumno`, `nombre`, `apellido_p`, `apellido_m`, `password`, `nivel`, `especialidad`, `codigo`) VALUES ('$matricula','$nombre','$apellido_p','$apellido_m','$codigo','$nivel','$especialidad','$codigo2')") or die();
		
		$result=mysql_query("select * from alumnos a WHERE a.id_alumno = '".$matricula."' ") or die(mysql_error()); 
		
		$row = mysql_fetch_array($result);
		
				$to = $row['id_alumno'];
				$to = $to."@itesm.mx";
				$subject = "Alta Alumno";
				
				$message = "
				<html>
				<head>
				<title>Alta Alumno</title>
				</head>
				<body>
				<p>Equipo EvaluaMed:</p>
				<p>Se te ha dado de alta en el sistema. A continuaci&oacute;n se despliega la informaci&oacute;n.</p>
				<table>
				<tr>
				<td>Matricula:</td><td>".$row['id_alumno']."</td>
				</tr>
				<tr>
				<td>Nombre(s):</td><td>".$row['nombre']."</td>
				</tr>
				<tr>
				<td>Apellido Paterno:</td><td>".$row['apellido_p']."</td>
				</tr>
				<tr>
				<td>Apellido Materno:</td><td>".$row['apellido_m']."</td>
				</tr>
				<tr>
				<td>Nivel:</td><td>R".$row['nivel']."</td>
				</tr>
				<tr>
				<td>Especialidad:</td><td>".$row['especialidad']."</td>
				</tr>
				<tr>
				<td>Contrase&ntilde;a:</td><td>".$row['password']."</td>
				</tr>
				</table>
				<p>Este mensaje es autom&aacute;tico favor de no contestar.</p>
				</body>
				</html>
				";
				
				// Always set content-type when sending HTML email
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				
				// More headers
				$headers .= 'From: <mensajes@evaluacionqx.com>' . "\r\n";

				
				mail($to,$subject,$message,$headers);
		
		$respuesta = 1;
		
		// Se manda el nombre del equipo
		echo $respuesta;

	}
	?>