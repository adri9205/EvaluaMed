<!DOCTYPE html>
<?php
session_start();
$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))||($_SESSION['username']!="admin")){
	
	header("location:default.html");
	
}

if($_SESSION['username']=="admin")
include("MenuSuperAdmin.html");
include 'configuration.php';

$result=mysql_query("SELECT * FROM `administrador`") or die(mysql_error()); 

$row = mysql_fetch_array($result);
	?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lista Alumnos</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="table.css" type="text/css"/>
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link href="textos.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<script src="jquery-1.10.2.js"></script>
<script>


function cambiaremail() {

	document.getElementById("error").innerHTML = "";
	var result=0;
	
	var email= document.getElementById("email").value;
	var email_c= document.getElementById("email_c").value;
	
	if((email!="")||(email_c!="")){
	
		if((/^[_a-z0-9-]+(.[_a-z0-9-]+)*@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,4})$/.test(email))&&(/^[_a-z0-9-]+(.[_a-z0-9-]+)*@[a-z0-9-]+(.[a-z0-9-]+)*(.[a-z]{2,4})$/.test(email_c))){
		
			if(email==email_c){
			
				
			    $.ajax({
			           type: 'GET',
			            url : 'c_email.php',
			            async: false,
			            data: {email:email, email_c:email_c},
			            success: function(resultado) {
			                result = resultado;
			            }
			        });
			         
			         if(result==1)
			         	alert("Cambios Guardadso");
			         else
			         	alert("Opps Error en la base de datos");
			}
			else{
				document.getElementById("error").innerHTML = "Contrase&ntilde;as no coinciden";
				
			}
			
			}
		else{
		
			document.getElementById("error").innerHTML = "Formato de correos no valido";
			
		}
	
	}
	else{
		document.getElementById("error").innerHTML = "Los campos no pueden estar vacios";
		
	}
	
}


function checkSubmit(e)
{
   if(e && e.keyCode == 13)
   {
      cambiaremail();
   }
}
</script>
</head>
<body style="background-color:lightgrey">
<h3>Cambiar Correo Electr&oacute;nico</h3>
<div>
<div class="formulario" onKeyPress="return checkSubmit(event)">
        <p>Correo Electr&oacute;nico:</p>
        <?php
        echo "<input type='text' id='email' name='email' value='".$row['correo']."' />";
        ?>
        <br>
        <p>Confirmar Correo Electr&oacute;nico:</p>
        <?php
        echo "<input type='text' id='email_c' name='email_c' value='".$row['correo']."' />";
        ?>
        <br>
        <br>
        <p></p>
  	<button type="button" class="base" onclick="cambiaremail()">Cambiar Correo Electr&oacute;nico</button>
	<br>
	<p id="error" class="error"></p>
</div>
<div class="salida" id="salida">
</div>
</div>
</body>
</html>