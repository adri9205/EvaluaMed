<?php
session_start();
$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))||($_SESSION['username']!="admin")){
	
	header("location:default.html");
	
}

include 'configuration.php';

		$especialidad 		= $_GET['especialidad'];
		$nivel	 		= $_GET['nivel'];
		$titular 		= $_GET['titular'];


		mysql_query("UPDATE `grupos` SET `id_titular`='".$titular."' WHERE `id_especialidad`='".$especialidad."' AND `nivel`='".$nivel."'") or die();
		
		if($titular != ""){
		
				$to = $titular;
				$subject = "Alta Titular De Grupo";
				
				$message = "
				<html>
				<head>
				<title>Alta Titular de Grupo</title>
				</head>
				<body>
				<p>Equipo EvaluaMed:</p>
				<p>Se te ha dado de alta como titular de un nuevo grupo en el sistema. A continuaci&oacute;n se despliega la informaci&oacute;n.</p>
				<table>
				<tr>
				<td>Especialidad:</td><td>".$especialidad."</td>
				</tr>
				<tr>
				<td>Nivel:</td><td>R".$nivel."</td>
				</tr>
				</table>
				<p>Este mensaje es autom&aacute;tico favor de no contestar.</p>
				</body>
				</html>
				";
				
				// Always set content-type when sending HTML email
				$headers = "MIME-Version: 1.0" . "\r\n";
				$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
				
				// More headers
				$headers .= 'From: <mensajes@evaluacionqx.com>' . "\r\n";

				
				mail($to,$subject,$message,$headers);
				
		}

	?>