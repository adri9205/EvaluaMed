<!DOCTYPE html>
<?php
session_start();
$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))&&($_SESSION['username']=="admin")){
	
	header("location:default.html");
	
}

include("MenuSuperAdmin.html");
include 'configuration.php';

$correo 		= $_GET['id'];

$result=mysql_query("select * from evaluadores a WHERE a.id_evaluadores = '".$correo."' ") or die(mysql_error()); 

$row = mysql_fetch_array($result);
	?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lista Alumnos</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="table.css" type="text/css"/>
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link href="textos.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<script src="jquery-1.10.2.js"></script>
<script>

function dbevaluador() {

	var result= 0;
	
	document.getElementById("error").innerHTML = "";
	
	var correo= document.getElementById('correo').innerHTML;
	var nombre = document.getElementById('nombre').value;
	var apaterno = document.getElementById('apaterno').value;
	var amaterno = document.getElementById('amaterno').value;
	var especialidad = document.getElementById('especialidad').value;
	var radios = document.getElementsByName('titular');
	var titular;
	
	for (var i = 0, length = radios.length; i < length; i++) {
	    if (radios[i].checked) {
	        // do whatever you want with the checked radio
	        titular=radios[i].value;
	
	        // only one radio can be logically checked, don't check the rest
	        break;
	    }
	}

	if((correo!="")&&(nombre!="")&&(apaterno!="")&&(amaterno!="")&&(especialidad!="")&&(titular!=2)){
	
	    $.ajax({
	           type: 'GET',
	            url : 'modificar_cevaluador.php',
	            async: false,
	            data: {correo: correo, nombre: nombre, apaterno: apaterno, amaterno: amaterno, especialidad: especialidad, titular: titular},
	            success: function(resultado) {
	                result = resultado;
	            }
	        });
	        
	        if(result == 1){
	        
	        	document.getElementById("estatus").innerHTML = "<img src='images/checkmark.png' />";
	        	document.getElementById("mensaje").innerHTML = "CAMBIOS GUARDADOS";
	        }
	        
	        else{
	        
	        	document.getElementById("estatus").innerHTML = "<img src='images/alerta.png' />";
	        	document.getElementById("mensaje").innerHTML = "ERROR EN LA BASE DE DATOS";
	        
	        }
	        
	        }
	        else{
	        
	        	document.getElementById("error").innerHTML = "Completar todos los campos";
	        }
	
}

</script>
</head>
<body style="background-color:lightgrey">
<h3>Editar los datos del evaluador</h3>
<div>
<div class="formulario">
<form>
        <p>Correo Electr&oacute;nico:</p>
        <?php
        echo "<p id='correo' name='correo' value='".$row['id_evaluadores']."'>".$row['id_evaluadores']."</p>";
        ?>
        <p>Nombre(s):</p>
       <?php
        echo "<input type='text' id='nombre' name='nombre' value='".$row['nombre']."' />";
        ?>
        <br>
        <p>Apellido Paterno:</p>
        <?php
        echo "<input type='text' id='apaterno' name='apaterno' value='".$row['apellido_p']."' />";
        ?>
        <br>
        <p>Apellido Materno:</p>
        <?php
        echo "<input type='text' id='amaterno' name='amaterno' value='".$row['apellido_m']."' />";
        ?>
        <br>
        <p>Especialidad:</p>
        <?php
        echo "<input type='text' id='especialidad' name='especialidad' value='".$row['especialidad']."' />";
        ?>
        <br>
	<p>Estatus:</p>
	<?php 
	
	if($row['titular']  == 1){
		echo "<input type='radio' name='titular' id='titular' value='1' checked> Activo";
		echo "<input type='radio' name='titular' id='titular' value='0'> Inactivo";}
	if($row['titular'] == 0){
		echo "<input type='radio' name='titular' id='titular' value='1'> Activo";
		echo "<input type='radio' name='titular' id='titular' value='0' checked> Inactivo";}
		
                       ?>
	<br>
	<br>
  	<button type="button" class="base" onclick="dbevaluador()">Guardar Cambios</button>
	<br>
	<p id="error" class="error"></p>
	</form>
</div>
<div class="salida" id="salida">
<p id="estatus"></p>
<p id="mensaje"></p>
</div>
</div>
</body>
</html>