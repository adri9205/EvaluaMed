<!DOCTYPE html>
<?php
session_start();
$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))&&($_SESSION['username']=="admin")){
	
	header("location:default.html");
	
}

include("MenuSuperAdmin.html");
include 'configuration.php';
	?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Lista Alumnos</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="table.css" type="text/css"/>
<link rel="stylesheet" type="text/css" href="Estilos.css">
<link href="textos.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryMenuBarHorizontal.css" rel="stylesheet" type="text/css" />
<script src="SpryAssets/SpryMenuBar.js" type="text/javascript"></script>
<script src="jquery-1.10.2.js"></script>
<script>


function refrescar() {

	document.getElementById("error").innerHTML = "";
	
		document.getElementById("salida").innerHTML = "";
	        if (window.XMLHttpRequest)
	        {// code for IE7+, Firefox, Chrome, Opera, Safari
	            xmlhttp = new XMLHttpRequest();
	        }
	        else
	        {// code for IE6, IE5
	            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	        }
	        xmlhttp.onreadystatechange = function()
	        {
	            if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
	            {
	                document.getElementById("salida").innerHTML = xmlhttp.responseText;
	            }
	        }
	
	        //Manda comoo argumentos la clave, el numero de pregunta y el orden
	        xmlhttp.open("GET", "refrescar_especialidad.php", true);
	        xmlhttp.send();
	        
	       
	
}

function dbespecialidad() {

	document.getElementById("error").innerHTML = "";
	
	var nombre = document.getElementById("nombre").value;

	if(nombre!=""){
	
		 $.ajax({
	           type: 'GET',
	            url : 'db_especialidad.php',
	            async: false,
	            data: {nombre: nombre},
	            success: function(resultado) {
	                
	            }
	        });
	        
	        document.getElementById("nombre").value="";
	        refrescar();
	}
	else{
	        
	        document.getElementById("error").innerHTML = "Campos vac&iacute;os";
	  	}

}

function borrar(id_especialidad, nombre_especialidad) {

	var confirmacion = confirm("Desea borrar la especialidad "+nombre_especialidad+"?");
	
	if(confirmacion){
	
		$.ajax({
		           type: 'GET',
		            url : 'borrar_especialidad.php',
		            async: false,
		            data: {id_especialidad: id_especialidad},
		            success: function(resultado) {
		               
		            }
		        });
		       
		        refrescar();
	        
	        }
}
function checkSubmit(e)
{
   if(e && e.keyCode == 13)
   {
      dbespecialidad();
   }

}
</script>
</head>
<body style="background-color:lightgrey" onload="refrescar()">
<h3>Ingrese los datos para la b&uacute;squeda de la especialidad</h3>
<div>
<div class="formulario" onKeyPress="return checkSubmit(event)">
        <p>Nombre de la especialidad:</p>
        <input type="text" id="nombre" name="nombre">
        <br>
        <p id="error" class="error"></p>
  	<button type="button" class="base" onclick="dbespecialidad()">Agregar Especialidad</button>
	<br>
</div>
<div class="salida" id="salida">
</div>
</div>
</body>
</html>