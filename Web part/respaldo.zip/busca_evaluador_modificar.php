<?php

$id=$_SESSION['cookie1'];
if((!isset($_SESSION['username']))&&($_SESSION['username']=="admin")){
	
	header("location:default.html");
	
}

include 'configuration.php';

		$correo 		= $_GET['correo'];
		$nombre 		= $_GET['nombre'];
		$apellido_p 		= $_GET['apaterno'];
		$apellido_m 		= $_GET['amaterno'];
		$especialidad 		= $_GET['especialidad'];
		$titular 		= $_GET['titular'];
		
		if($correo!= ""){
		
			$result=mysql_query("select * from evaluadores a WHERE a.id_evaluadores = '".$correo."' ") or die(mysql_error()); 
			
		}
		else if(($nombre != "") || ($apellido_p != "") || ($apellido_m != "")){
		
			if($nombre != ""){
				
				$nombrebd = "a.nombre= '".$nombre."'";
			}
			else{
			
				$nombrebd = "";
			
			}
			if ($apellido_p != ""){
			
				if($nombre != ""){
			
					$apellido_pbd = "AND a.apellido_p= '".$apellido_p."'";
				}
				else{
					
					$apellido_pbd = "a.apellido_p= '".$apellido_p."'";
				}
			}
			else{
			
				$apellido_pbd = "";
			}
			if ($apellido_m != ""){
			
				if(($nombre != "") || ($apellido_p != "")){
			
					$apellido_mbd = "AND a.apellido_m= '".$apellido_m."'";
				
				}
				else{
				
					$apellido_mbd = "a.apellido_m= '".$apellido_m."' ";
				}
			}
			else{
			
				$apellido_mbd = "";
			}
			
			$result=mysql_query("select * from evaluadores a WHERE ".$nombrebd.$apellido_pbd.$apellido_mbd."") or die(mysql_error()); 
		
		}
		else if($especialidad != ""){
		
			$result=mysql_query("select * from evaluadores a WHERE a.especialidad= '".$especialidad."'  ") or die(mysql_error()); 
		
		}
		else{
		
			$result=mysql_query("select * from evaluadores a WHERE a.titular= '".$titular."'  ") or die(mysql_error());
		
		}
		

	$row = mysql_fetch_array($result);
	if($row != NULL){
		
	echo " <p></p>";
	echo "	<table class='as_gridder_table'>";
        echo "    <tr class='grid_header'>";
        echo "        <td>Correo</td>";
        echo "        <td>Nombre(s)</td>";
        echo "        <td>Apellido P</td>";
        echo "        <td>Apellido M</td>";
        echo "        <td>Especialidad</td>";
        echo "        <td>Estatus</td>";
               
        echo "    </tr>";
        
        do{ 
        
        
        echo "    <tr style='background-color:#FFFFFF'>";
                 
        echo "            <td><a href='http://evaluacionqx.com/db_mevaluador.php?id=".$row['id_evaluadores']."'>".$row['id_evaluadores']."</a></td>";
        echo "            <td>".$row['nombre']."</td>";
        echo "            <td>".$row['apellido_p']."</td>";
        echo "            <td>".$row['apellido_m']."</td>";
        echo "     	 <td>"  .$row['especialidad']. " </td>";
        
        if($row['titular'] == 1){
        
        	echo "      	<td>Activo</td>";
        	
        }
        else{
        
        	echo "      	<td>Inactivo</td>";
        
        }
                    
                   
                    
	echo "			</tr>";
				
		}while($row = mysql_fetch_array($result)); 
         echo "       </table>";
						
	}  
	
	else {
		
		echo "<p> No se encontr&oacute; alg&uacute;n evaluador con esos datos. </p>";

	}
?>